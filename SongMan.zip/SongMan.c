
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>

#define FALSE 0
#define TRUE 1
int P=1;
struct datetime{
	int day;
	int month;
	int year;
	int hour;
	int minute;
};

struct songNode{
    	int ID;
    	struct datetime *dt;
        char songName[250];
        char songGenre[250];
        char albumName[250];
        char artistName[250];
        char releasedYear[250];
        struct songNode *next;
    };

struct songRecord{
	struct songNode *head;
	struct songNode *tail;
	int size;
};
typedef struct songRecord* song;

int IsEmptylist(song s);
song initialiseSongs(void);
song addSong(char[],char[],char[],char[],char[],song);
song deleteSong(song,int);
void printSongs(song);
void searchSongs(song);
void createPlayList(song);
void Overwrite(song);


int main(){  
  
	song songList;
	char command;
	int exit = FALSE;
	
	
	char songscan[250];
	char genrescan[250];
	char albumscan[250];
	char artistscan[250];
	char yearscan[250];
	int IDscan;
	
	fflush(stdin);
	songList=initialiseSongs();
	
	printf("The SonMan.txt file has been loaded successfully\n ");
	while (!exit){
		
		printf("\n------MENU------\n\n1. Add Song\n2. Delete Song\n3. Print Songs\n4. Search Songs\n5. Create PlayList\nx: Exit\n\nEnter your option: ");
		scanf("%c", &command);
		fflush(stdin);
		printf("\n");
		switch (command)
		{
		case '1':
			printf("Enter name of the song: ");
			gets(songscan);
			fflush(stdin);
			
			printf("Enter genre of the song: ");
			gets(genrescan);
			fflush(stdin);
			
			printf("Enter name of the album:  ");
			gets(albumscan);
			fflush(stdin);
			
			printf("Enter name of the artist: ");
			gets(artistscan);
			fflush(stdin);
			
			printf("Enter year of the song: ");
			gets(yearscan);
			fflush(stdin);
			
			songList=addSong(songscan,genrescan,albumscan,artistscan,yearscan,songList);
			printf("The song has been added!!\n");
			break;
		case '2':
			printf("Enter the ID of the song you want to delete: ");
			scanf("%d",&IDscan);
			fflush(stdin);
			
			if(IDscan<1 || IDscan > songList->size)
				printf("No song with ID %d in your list!\n",IDscan);
			else{
				songList=deleteSong(songList,IDscan);
				printf("Song with ID %d has been deleted from your list!!! \n",IDscan);		}
			break;
		case '3':
			printSongs(songList);
			break;
		case '4':
			searchSongs(songList);
			break;
		case '5':
			createPlayList(songList);
			break;			
		case 'x':
			Overwrite(songList);
			printf("The SonMan.txt file has been updated successfully!! ");
			exit = TRUE;
			break;
		default:
			printf("Command is not recognized!\n");
			break;
		}
	}
	printf("Goodbye!! ");
	system("PAUSE");
	return 0;
} 
int IsEmptylist(song s)
{
	return (s->size==0);
}

song initialiseSongs(){
	
	
	FILE *slistpt;
	slistpt = fopen("SongMan.txt","r");
	
	if(slistpt == NULL)
	{
		printf("FAILED!\n");
		exit(1);
	}
	
	
	song listSong;
	
	listSong = (struct songRecord*)malloc(sizeof(struct songRecord));
	listSong->head = (struct songNode*)malloc(sizeof(struct songNode));
	listSong->head->dt = (struct datetime*)malloc(sizeof(struct datetime));
	listSong->tail=listSong->head;
	listSong->size=0;
	
	struct songNode *temp;
	temp=listSong->head;
	temp->next= (struct songNode*)malloc(sizeof(struct songNode));
	temp->next->dt = (struct datetime*)malloc(sizeof(struct datetime));
	temp->next->next=NULL;
	temp=temp->next;
	
	
	
	
	while(fscanf(slistpt,"%d ;%[^;];%[^;];%[^;];%[^;];%[^;];%d/%d/%d %d:%d\n",&temp->ID,temp->songName,temp->songGenre,temp->albumName,temp->artistName,&temp->releasedYear,&temp->dt->day,&temp->dt->month,&temp->dt->year,&temp->dt->hour,&temp->dt->minute) != EOF)
	{	 
		
		 fflush(stdin);
		 listSong->size++;
		 if(feof(slistpt)) break;
		 temp->next=(struct songNode*)malloc(sizeof(struct songNode));
		 temp->next->dt=(struct datetime*)malloc(sizeof(struct datetime));
		 temp->next->next=NULL;
		 temp=temp->next;
		 listSong->tail=temp;
		 
	}
	fclose(slistpt);
	
	return listSong;
}



song addSong(char name[],char genre[],char album[],char artist[],char year[], song s){
	
	time_t ti = time(NULL);
	struct tm t = *localtime(&ti);
	
	
	struct songNode *newSong,*temp;
	newSong = (struct songNode*)malloc(sizeof(struct songNode));
	newSong->dt = (struct datetime*)malloc(sizeof(struct datetime));
	newSong->next=NULL;
	
	strcpy(newSong->songName,name);
	strcpy(newSong->songGenre,genre);
	strcpy(newSong->albumName,album);
	strcpy(newSong->artistName,artist);
	strcpy(newSong->releasedYear,year);
	newSong->dt->day = t.tm_mday;
	newSong->dt->month = t.tm_mon+1;
	newSong->dt->year= t.tm_mon+1+2008;	
	newSong->dt->hour = t.tm_hour;
	newSong->dt->minute = t.tm_min;
	newSong->ID = s->tail->ID+1;
	
	
	if(IsEmptylist(s))
	{
		s->tail->next=newSong->next;
		s->tail=newSong;	
	}
	
	else
	{
		temp=s->head;
		while(temp->next!=NULL)
		{
			temp=temp->next;
		}
			newSong->next=temp->next;
			temp->next=newSong;
			s->tail=temp->next;
		
	}
	s->size++;
	
	return s;
	

}
song deleteSong(song s, int pos){
	
	struct songNode *del, *temp;
	
	temp = s->head;
	
	if(IsEmptylist(s))
		printf("No songs in your song list\n");
	else
	{
	
		while((temp->next != NULL) && (temp->next->ID != pos))
			temp=temp->next;
			
		del = temp->next;
		temp->next = temp->next->next;
		free(del);
		
		s->size--;
	}
	
	
	return s;

}
void printSongs(song list){
	
	struct datetime *dt;
	struct songNode *p;
	
	p=list->head->next;

	printf("Songs in your database:\n");
	printf("--------------------------\n");
	while(p!=NULL)
	{
		
		printf("ID: %d\n",p->ID);
		printf("Song Name: %s\n",p->songName);
		printf("Song Genre: %s\n",p->songGenre);
		printf("Album Name: %s\n",p->albumName);
		printf("Artist Name: %s\n",p->artistName);
		printf("Year: %s\n",p->releasedYear);
		printf("Date: %02d/%02d/%04d\n",p->dt->day,p->dt->month,p->dt->year);
		printf("Time: %02d:%02d\n",p->dt->hour,p->dt->minute);
		
		printf("\n");
		p=p->next;
	}
	
	printf("\n");
	
}
void searchSongs(song s){
	int option,lenght,j;
	char sName[100];
	char aName[100];
	char gName[100];
	struct songNode *searchSong;
	searchSong = s->head;
	int find= FALSE;
	int i;
	printf("---- Searching by ---- \n");
	printf("(1) song name \n(2) artist name \n(3) genre\n");
	printf("Enter search by option: ");
	scanf("%d",&option);
	fflush(stdin);
	switch(option){
		case 1:
			printf("Song Name: ");
			gets(sName);
			fflush(stdin);
			printf("\n");
			for(i=0;i<s->size;i++){
				while(searchSong!=NULL){
					if(strcmp(searchSong->songName,sName)==0){
						find = TRUE;
						printf("ID:  %d\n",searchSong->ID);
						printf("Song Name: %s\n",searchSong->songName);
						printf("Song Genre: %s\n",searchSong->songGenre);
						printf("Album Name: %s\n",searchSong->albumName);
						printf("Artist Name: %s\n",searchSong->artistName);
						printf("Year: %s\n",searchSong->releasedYear);
						printf("Date: %02d/%02d/%04d\n",searchSong->dt->day,searchSong->dt->month,searchSong->dt->year);
						printf("Time: %02d:%02d\n",searchSong->dt->hour,searchSong->dt->minute);
						
						printf("\n");
						
					}
					searchSong=searchSong->next;
				}
				
			}
			if(find == FALSE) printf("Not Found!\n");
			
			break;
		case 2:
			printf("Artist Name: ");
			gets(aName);
			fflush(stdin);
			printf("\n");
			for(i=0;i<s->size;i++){
				while(searchSong!=NULL){
					if(strcmp(searchSong->artistName,aName)==0){
						find = TRUE;
						printf("ID:  %d\n",searchSong->ID);
						printf("Song Name: %s\n",searchSong->songName);
						printf("Song Genre: %s\n",searchSong->songGenre);
						printf("Album Name: %s\n",searchSong->albumName);
						printf("Artist Name: %s\n",searchSong->artistName);
						printf("Year: %s\n",searchSong->releasedYear);
						printf("Date: %02d/%02d/%04d\n",searchSong->dt->day,searchSong->dt->month,searchSong->dt->year);
						printf("Time: %02d:%02d\n",searchSong->dt->hour,searchSong->dt->minute);
						
						printf("\n");
						
					}
					searchSong=searchSong->next;
				}
			}
			if(find == FALSE) printf("Not Found!\n");
			
			
			break;
		case 3:
			printf("Genre: ");
			gets(gName);
			fflush(stdin);
			printf("\n");
			for(i=0;i<s->size;i++){
				while(searchSong!=NULL){
					if(strcmp(searchSong->songGenre,gName)==0){
						find = TRUE;
						printf("ID:  %d\n",searchSong->ID);
						printf("Song Name: %s\n",searchSong->songName);
						printf("Song Genre: %s\n",searchSong->songGenre);
						printf("Album Name: %s\n",searchSong->albumName);
						printf("Artist Name: %s\n",searchSong->artistName);
						printf("Year: %s\n",searchSong->releasedYear);
						printf("Date: %02d/%02d/%04d\n",searchSong->dt->day,searchSong->dt->month,searchSong->dt->year);
						printf("Time: %02d:%02d\n",searchSong->dt->hour,searchSong->dt->minute);
						printf("\n");	
					}
					searchSong=searchSong->next;
				}
			}
			if(find == FALSE) printf("Not Found!\n");
			
			
			break;
		default:
			printf("Please enter a valid option!\n");
			break;			
	}
	
}
void createPlayList(song s){
	
	FILE *playlistptr;
	char name[50];
	
	struct songNode *newList;
	newList = s->head->next;
	
	int playlistarray[3];
	
	int option,i,j,k=0;
	char nameSong[250];
	int find =FALSE;
	
	struct songNode *p;
	p=s->head->next;	
	
	printf("Enter the names of songs for your playlist: \n");
	for(i=1;i<4;i++){
		printf("Enter %d song name: ",i);
		gets(nameSong);
		fflush(stdin);
			while(p!=NULL){
				if(strcmp(p->songName,nameSong)==0){
					find = TRUE;
					if(i==1)
						playlistarray[0]=p->ID;
					else if(i==2)
						playlistarray[1]=p->ID;
					else
						playlistarray[2]=p->ID;	
				}		
				p=p->next;
			}
			p=s->head->next;
	}
	
	if(find == FALSE) printf("The playList cannot be created! Not all songs found!!! \n");
	else {
		printf("The playList has been created and stored in the file: PlayList-%d.txt!\n ",P);
		snprintf(name, sizeof(name), "Playlist-%d.txt", P);
		fopen_s(&playlistptr, name, "a");
		
		while(newList!=NULL){
			for(i=0;i<3;i++){
				if(newList->ID==playlistarray[i])
					fprintf(playlistptr,"%d;%s\n",newList->ID,newList->songName);
			}
			newList=newList->next;
		}
		fclose(playlistptr);
	}
	P++;

}
void Overwrite(song s){
	
	FILE *songlistptr;
	
	struct songNode *overlist;
	
	overlist = s->head->next;

	
	songlistptr=fopen("SongMan.txt","w");
	
	while(overlist!=NULL)
	{
		fprintf(songlistptr,"%d;%s;%s;%s;%s;%s;%d/%d/%d %d:%d\n",overlist->ID,overlist->songName,overlist->songGenre,overlist->albumName,overlist->artistName,overlist->releasedYear,overlist->dt->day,overlist->dt->month,overlist->dt->year,overlist->dt->hour,overlist->dt->minute);
		overlist=overlist->next;
	}
	fclose(songlistptr);	
}
